#include <stdio.h>
#include "funcoesmath.h" 
#include "funcoesmatemati.h"

int main()
{
	printf("%d\n ",pot(2,4));
	printf("%d\n",fatorial(13));
        printf("%d\n",calcn(20));
        printf("%d\n",seno
	return 0;
}
