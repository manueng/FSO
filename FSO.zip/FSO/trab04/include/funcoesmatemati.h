#ifndef FUNCOESMATEMATICAS_H
#define FUNCOESMATEMATI_H
 double funcaoseno(int n);
 double funcaoarcseno( double n);
#endif 

