#ifndef FUNCOESMATH_H
#define FUNCOESMATH_H
 unsigned int fatorial(int numero);
 int pot( int numero, int potencia);
 int  calcn(int n);
#endif 

